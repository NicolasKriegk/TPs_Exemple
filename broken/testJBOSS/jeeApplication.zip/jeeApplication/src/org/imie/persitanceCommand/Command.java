package org.imie.persitanceCommand;

public interface Command {

	
	public Object execute();

}
