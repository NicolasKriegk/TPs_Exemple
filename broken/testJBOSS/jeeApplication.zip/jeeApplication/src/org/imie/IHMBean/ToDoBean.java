package org.imie.IHMBean;

public class ToDoBean {
	
	private Double numero;
	private String texte;
	public Double getNumero() {
		return numero;
	}
	public void setNumero(Double numero) {
		this.numero = numero;
	}
	public String getTexte() {
		return texte;
	}
	public void setTexte(String texte) {
		this.texte = texte;
	}
	
}
